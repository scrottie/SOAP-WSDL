package SOAP::WSDL::XSD::Typelib::Builtin::language;
use strict;
use warnings;
use Class::Std::Fast::Storable;
use base qw(SOAP::WSDL::XSD::Typelib::Builtin::token);

1;
