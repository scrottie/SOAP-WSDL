package SOAP::WSDL::XSD::Typelib::Builtin::negativeInteger;
use strict;
use warnings;
use Class::Std::Fast::Storable constructor => 'none', cache => 1;
use base qw(SOAP::WSDL::XSD::Typelib::Builtin::nonPositiveInteger);

1;
