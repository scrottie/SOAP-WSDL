package SOAP::WSDL::Generator::Visitor::Typelib;
use strict;
use warnings;
use base qw(SOAP::WSDL::Generator::Visitor
    SOAP::WSDL::Generator::Template
);

use version; our $VERSION = qv('2.00.01');

1;

