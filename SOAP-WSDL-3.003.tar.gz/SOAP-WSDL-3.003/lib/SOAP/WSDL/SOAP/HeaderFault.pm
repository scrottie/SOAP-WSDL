package SOAP::WSDL::SOAP::HeaderFault;
use strict;
use warnings;
use base qw(SOAP::WSDL::SOAP::Header);

our $VERSION = 3.003;

1;
