package SOAP::WSDL::SOAP::Typelib::Fault;
use strict;
use warnings;
use Class::Std::Fast::Storable constructor => 'none';

our $VERSION = 3.003;

1;