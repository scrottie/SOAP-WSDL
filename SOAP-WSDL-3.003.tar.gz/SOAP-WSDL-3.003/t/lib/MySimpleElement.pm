package MySimpleElement;

use strict; use warnings;
use base qw(SOAP::WSDL::XSD::Typelib::Element
    SOAP::WSDL::XSD::Typelib::Builtin::integer);

sub get_xmlns { 'urn:Test' }

__PACKAGE__->__set_name('MySimpleElement');

1;